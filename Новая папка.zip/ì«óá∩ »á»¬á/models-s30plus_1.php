<?php

namespace WhichBrowser\Data;

DeviceModels::$S30PLUS_INDEX = array (
  '@21' => 
  array (
    0 => 215,
  ),
  '@22' => 
  array (
    0 => 220,
    1 => 222,
    2 => 225,
  ),
  '@23' => 
  array (
    0 => 230,
  ),
);
