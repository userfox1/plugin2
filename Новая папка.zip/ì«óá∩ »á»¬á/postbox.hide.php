<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $(".postbox button.handlediv").click(function(){
           $(this).parent('.postbox').toggleClass("closed");
        });
    });
</script>