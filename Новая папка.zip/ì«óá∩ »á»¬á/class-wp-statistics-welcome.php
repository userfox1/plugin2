<?php
if (!class_exists('WP_Statistics_Welcome')) {
    class WP_Statistics_Welcome
    {
        public static function init()
        {
        }

        public static function menu()
        {
        }

        public static function page_callback()
        {
        }

        public static function do_welcome($upgrader_object, $options)
        {
        }

        public static function show_change_log()
        {
        }
    }
}
